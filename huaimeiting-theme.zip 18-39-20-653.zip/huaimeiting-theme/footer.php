<?php
/**
 * The footer for the theme
 *
 * @package HuaiMei_Medical_Theme
 */

?>

<footer id="colophon" class="site-footer">
    <p>&copy; <?php echo date('Y'); ?> 怀美医疗 HuaiMei Medical. All Rights Reserved.</p>
</footer>

<?php wp_footer(); ?>
</body>
</html>
