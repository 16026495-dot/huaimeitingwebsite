<?php

if (!defined('ABSPATH')) {
    exit;
}

function huaimeiting_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    add_theme_support('custom-background', array(
        'default-color' => 'ffffff',
    ));
    
    register_nav_menus(array(
        'primary' => __('Primary Menu', 'huaimeiting-theme'),
        'footer'  => __('Footer Menu', 'huaimeiting-theme'),
    ));
    
    load_theme_textdomain('huaimeiting-theme', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'huaimeiting_theme_setup');

function huaimeiting_theme_scripts() {
    wp_enqueue_style('huaimeiting-style', get_stylesheet_uri(), array(), '1.0.0');
    
    if (is_singular() && comments_open() && get_option('thread_comments')) {
        wp_enqueue_script('comment-reply');
    }
}
add_action('wp_enqueue_scripts', 'huaimeiting_theme_scripts');

function huaimeiting_theme_widgets_init() {
    register_sidebar(array(
        'name'          => __('Footer Widget 1', 'huaimeiting-theme'),
        'id'            => 'footer-1',
        'description'   => __('Add widgets for footer section 1.', 'huaimeiting-theme'),
        'before_widget' => '<div id="%1$s" class="footer-section %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Widget 2', 'huaimeiting-theme'),
        'id'            => 'footer-2',
        'description'   => __('Add widgets for footer section 2.', 'huaimeiting-theme'),
        'before_widget' => '<div id="%1$s" class="footer-section %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));
    
    register_sidebar(array(
        'name'          => __('Footer Widget 3', 'huaimeiting-theme'),
        'id'            => 'footer-3',
        'description'   => __('Add widgets for footer section 3.', 'huaimeiting-theme'),
        'before_widget' => '<div id="%1$s" class="footer-section %2$s">',
        'after_widget'  => '</div>',
        'before_title'  => '<h3>',
        'after_title'   => '</h3>',
    ));
}
add_action('widgets_init', 'huaimeiting_theme_widgets_init');

function huaimeiting_theme_custom_post_types() {
    register_post_type('service', array(
        'labels' => array(
            'name'               => __('Services', 'huaimeiting-theme'),
            'singular_name'      => __('Service', 'huaimeiting-theme'),
            'add_new'            => __('Add New', 'huaimeiting-theme'),
            'add_new_item'       => __('Add New Service', 'huaimeiting-theme'),
            'edit_item'          => __('Edit Service', 'huaimeiting-theme'),
            'new_item'           => __('New Service', 'huaimeiting-theme'),
            'view_item'          => __('View Service', 'huaimeiting-theme'),
            'search_items'       => __('Search Services', 'huaimeiting-theme'),
            'not_found'          => __('No services found', 'huaimeiting-theme'),
            'not_found_in_trash' => __('No services found in Trash', 'huaimeiting-theme'),
        ),
        'public'       => true,
        'has_archive'  => true,
        'menu_icon'    => 'dashicons-clipboard',
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite'      => array('slug' => 'services'),
    ));
    
    register_post_type('product', array(
        'labels' => array(
            'name'               => __('Products', 'huaimeiting-theme'),
            'singular_name'      => __('Product', 'huaimeiting-theme'),
            'add_new'            => __('Add New', 'huaimeiting-theme'),
            'add_new_item'       => __('Add New Product', 'huaimeiting-theme'),
            'edit_item'          => __('Edit Product', 'huaimeiting-theme'),
            'new_item'           => __('New Product', 'huaimeiting-theme'),
            'view_item'          => __('View Product', 'huaimeiting-theme'),
            'search_items'       => __('Search Products', 'huaimeiting-theme'),
            'not_found'          => __('No products found', 'huaimeiting-theme'),
            'not_found_in_trash' => __('No products found in Trash', 'huaimeiting-theme'),
        ),
        'public'       => true,
        'has_archive'  => true,
        'menu_icon'    => 'dashicons-cart',
        'supports'     => array('title', 'editor', 'thumbnail', 'excerpt'),
        'rewrite'      => array('slug' => 'products'),
    ));
}
add_action('init', 'huaimeiting_theme_custom_post_types');

function huaimeiting_theme_customize_register($wp_customize) {
    $wp_customize->add_section('huaimeiting_theme_options', array(
        'title'    => __('Theme Options', 'huaimeiting-theme'),
        'priority' => 130,
    ));
    
    $wp_customize->add_setting('hero_title', array(
        'default'           => 'Our Strengths 核心优势',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_title', array(
        'label'   => __('Hero Title', 'huaimeiting-theme'),
        'section' => 'huaimeiting_theme_options',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('hero_subtitle', array(
        'default'           => 'Professional medical compression garments for postoperative recovery and postnatal care',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('hero_subtitle', array(
        'label'   => __('Hero Subtitle', 'huaimeiting-theme'),
        'section' => 'huaimeiting_theme_options',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('cta_text', array(
        'default'           => 'Contact Us Today',
        'sanitize_callback' => 'sanitize_text_field',
    ));
    
    $wp_customize->add_control('cta_text', array(
        'label'   => __('CTA Button Text', 'huaimeiting-theme'),
        'section' => 'huaimeiting_theme_options',
        'type'    => 'text',
    ));
    
    $wp_customize->add_setting('cta_url', array(
        'default'           => '#contact',
        'sanitize_callback' => 'esc_url_raw',
    ));
    
    $wp_customize->add_control('cta_url', array(
        'label'   => __('CTA Button URL', 'huaimeiting-theme'),
        'section' => 'huaimeiting_theme_options',
        'type'    => 'url',
    ));
}
add_action('customize_register', 'huaimeiting_theme_customize_register');

function huaimeiting_theme_body_classes($classes) {
    if (!is_singular()) {
        $classes[] = 'hfeed';
    }
    
    if (is_active_sidebar('sidebar-1')) {
        $classes[] = 'has-sidebar';
    }
    
    return $classes;
}
add_filter('body_class', 'huaimeiting_theme_body_classes');

function huaimeiting_theme_pingback_header() {
    if (is_singular() && pings_open()) {
        printf('<link rel="pingback" href="%s">', esc_url(get_bloginfo('pingback_url')));
    }
}
add_action('wp_head', 'huaimeiting_theme_pingback_header');

function huaimeiting_theme_add_editor_styles() {
    add_editor_style('style.css');
}
add_action('admin_init', 'huaimeiting_theme_add_editor_styles');
