<?php
/**
 * The header for the theme
 *
 * @package HuaiMei_Medical_Theme
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header id="masthead" class="site-header">
    <div class="site-branding">
        <?php
        if (has_custom_logo()) :
            the_custom_logo();
        else :
            ?>
            <h1 class="site-title">
                <a href="<?php echo esc_url(home_url('/')); ?>" rel="home">
                    怀美医疗 HuaiMei Medical
                </a>
            </h1>
            <?php
        endif;
        ?>
    </div>

    <nav id="site-navigation" class="main-navigation">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'primary',
            'menu_id'        => 'primary-menu',
            'fallback_cb'    => 'huaimeiting_default_menu',
        ));
        ?>
    </nav>
</header>

<?php
function huaimeiting_default_menu() {
    echo '<ul id="primary-menu" class="menu nav-menu">';
    echo '<li><a href="#home">Home</a></li>';
    echo '<li><a href="#about">About</a></li>';
    echo '<li><a href="#products">Products</a></li>';
    echo '<li><a href="#services">Services</a></li>';
    echo '<li><a href="#contact">Contact</a></li>';
    echo '</ul>';
}
