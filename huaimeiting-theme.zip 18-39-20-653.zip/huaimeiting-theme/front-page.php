<?php
/**
 * The front page template file
 *
 * @package HuaiMei_Medical_Theme
 */

get_header();
?>

<main id="primary" class="site-main">

    <!-- Our Strengths Section -->
    <section class="section">
        <h1>Our Strengths核心优势</h1>
        
        <div class="strength-item">
            <div class="strength-number">01</div>
            <div class="strength-title">品牌使命</div>
            <p class="strength-description">
                我们秉持"医疗为本"的理念，专注医用塑身衣研发与生产，致力于为术后、产后人群提供安全有效的康复解决方案。
            </p>
        </div>

        <div class="strength-item">
            <div class="strength-number">02</div>
            <div class="strength-title">研发实力</div>
            <p class="strength-description">
                联合三甲医院临床医师共同研发，基于人体工学与临床数据，确保压力值精准达标，符合医用级标准。
            </p>
        </div>

        <div class="strength-item">
            <div class="strength-number">03</div>
            <div class="strength-title">服务网络</div>
            <p class="strength-description">
                提供从产品定制到临床指导的一站式服务，覆盖全国的销售与售后网络，高效支持医疗机构与终端用户。
            </p>
        </div>
    </section>

    <!-- Products & Services Section -->
    <section class="section">
        <h2>Our Products & Services / 产品与服务</h2>
        <p>Professional medical compression garments for postoperative recovery and postnatal care.</p>

        <div class="service-item">
            <div class="service-title">Postoperative Recovery Series</div>
            <div class="service-description">术后修复系列（吸脂/隆胸/胸外科术后专用塑身衣）</div>
        </div>

        <div class="service-item">
            <div class="service-title">Postnatal Care Series</div>
            <div class="service-description">产后康复系列（收腹/束身/哺乳专用塑身衣）</div>
        </div>

        <div class="service-item">
            <div class="service-title">Customized Medical Solutions</div>
            <div class="service-description">医疗机构定制方案</div>
        </div>

        <div class="service-item">
            <div class="service-title">24/7 Clinical Guidance</div>
            <div class="service-description">7×24小时专业穿戴指导</div>
        </div>

        <div class="service-item">
            <div class="service-title">Medical Device Certification</div>
            <div class="service-description">二类医疗器械资质认证</div>
        </div>

        <div class="service-item">
            <div class="service-title">OEM/ODM Production</div>
            <div class="service-description">贴牌与定制生产服务</div>
        </div>

        <div class="service-item">
            <div class="service-title">Hygiene & Safety Guarantee</div>
            <div class="service-description">医用级卫生安全保障</div>
        </div>

        <div class="service-item">
            <div class="service-title">Nationwide After-Sales Network</div>
            <div class="service-description">全国售后覆盖网络</div>
        </div>

        <div class="service-item">
            <div class="service-title">Personal Rehabilitation Adviser</div>
            <div class="service-description">专属康复顾问服务</div>
        </div>
    </section>

</main>

<?php
get_footer();
