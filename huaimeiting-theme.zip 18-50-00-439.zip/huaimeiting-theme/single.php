<?php
/**
 * The template for displaying all single posts
 *
 * @package HuaiMei_Medical_Theme
 */

get_header();
?>

<main id="primary" class="site-main">
    <div class="container" style="padding: 60px 20px;">
        <?php
        while (have_posts()) :
            the_post();
            ?>
            <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>
                <header class="entry-header">
                    <?php
                    if (is_singular()) :
                        the_title('<h1 class="entry-title">', '</h1>');
                    else :
                        the_title('<h2 class="entry-title"><a href="' . esc_url(get_permalink()) . '" rel="bookmark">', '</a></h2>');
                    endif;

                    if ('post' === get_post_type()) :
                        ?>
                        <div class="entry-meta">
                            <?php
                            echo '<span class="posted-on">' . get_the_date() . '</span>';
                            echo '<span class="byline"> by ' . get_the_author() . '</span>';
                            ?>
                        </div>
                    <?php endif; ?>
                </header>

                <?php if (has_post_thumbnail()) : ?>
                    <div class="post-thumbnail">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>

                <div class="entry-content">
                    <?php
                    the_content(
                        sprintf(
                            wp_kses(
                                __('Continue reading<span class="screen-reader-text"> "%s"</span>', 'huaimeiting-theme'),
                                array('span' => array('class' => array()))
                            ),
                            wp_kses_post(get_the_title())
                        )
                    );

                    wp_link_pages(array(
                        'before' => '<div class="page-links">' . esc_html__('Pages:', 'huaimeiting-theme'),
                        'after'  => '</div>',
                    ));
                    ?>
                </div>

                <footer class="entry-footer">
                    <?php
                    $categories_list = get_the_category_list(', ');
                    if ($categories_list) {
                        printf('<span class="cat-links">' . esc_html__('Posted in %s', 'huaimeiting-theme') . '</span>', $categories_list);
                    }

                    $tags_list = get_the_tag_list('', ', ');
                    if ($tags_list) {
                        printf('<span class="tags-links">' . esc_html__('Tagged %s', 'huaimeiting-theme') . '</span>', $tags_list);
                    }
                    ?>
                </footer>
            </article>
            <?php

            the_post_navigation(array(
                'prev_text' => '<span class="nav-subtitle">' . esc_html__('Previous:', 'huaimeiting-theme') . '</span> <span class="nav-title">%title</span>',
                'next_text' => '<span class="nav-subtitle">' . esc_html__('Next:', 'huaimeiting-theme') . '</span> <span class="nav-title">%title</span>',
            ));

            if (comments_open() || get_comments_number()) :
                comments_template();
            endif;

        endwhile;
        ?>
    </div>
</main>

<?php
get_footer();
