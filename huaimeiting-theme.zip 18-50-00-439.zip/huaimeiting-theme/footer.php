<?php
/**
 * The footer for the theme
 *
 * @package HuaiMei_Medical_Theme
 */
?>
<?php wp_footer(); ?>
</body>
</html>
