# HuaiMei Medical Theme

A professional WordPress theme for HuaiMei Medical (怀美医疗) - Medical Compression Garments website.

## Theme Features

- ✅ Responsive design
- ✅ Bilingual support (Chinese & English)
- ✅ Custom post types for Products and Services
- ✅ Theme customizer options
- ✅ SEO-friendly structure
- ✅ Fast loading and optimized
- ✅ Mobile-first approach

## Installation

### Method 1: WordPress Admin Dashboard
1. Log into your WordPress admin panel
2. Go to **Appearance → Themes → Add New**
3. Click **Upload Theme**
4. Choose the `huaimeiting-theme.zip` file
5. Click **Install Now**
6. After installation, click **Activate**

### Method 2: FTP Upload
1. Extract the `huaimeiting-theme.zip` file
2. Upload the `huaimeiting-theme` folder to `/wp-content/themes/`
3. Log into WordPress admin
4. Go to **Appearance → Themes**
5. Find "HuaiMei Medical Theme" and click **Activate**

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- MySQL 5.7 or higher

## Theme Customization

### Theme Options
Navigate to **Appearance → Customize** to access:
- Hero section title and subtitle
- CTA button text and URL
- Site logo and favicon
- Colors and typography

### Navigation Menu
1. Go to **Appearance → Menus**
2. Create a new menu
3. Add your pages
4. Assign to "Primary Menu" location

### Adding Products
1. Go to **Products → Add New**
2. Enter product title and description
3. Set featured image
4. Publish

### Adding Services
1. Go to **Services → Add New**
2. Enter service title and description
3. Set featured image
4. Publish

## File Structure

```
huaimeiting-theme/
├── style.css           # Main stylesheet and theme info
├── functions.php       # Theme functions and setup
├── header.php          # Header template
├── footer.php          # Footer template
├── index.php           # Main template
├── front-page.php      # Homepage template
├── page.php            # Single page template
├── single.php          # Single post template
└── README.md           # This file
```

## Color Palette

| Color Name   | Hex Code  | Usage                    |
|--------------|-----------|--------------------------|
| Primary Blue | #0073aa   | Headers, buttons, links  |
| Secondary    | #00a0d2   | Accents, highlights      |
| Dark Gray    | #23282d   | Footer background        |
| Light Gray   | #f7f7f7   | Section backgrounds      |
| White        | #ffffff   | Content background       |

## Support

For support or customization requests, please contact:
- Website: https://huaimeiting.wordpress.com
- Original Site: https://huaimeiting.42web.io

## Credits

- Theme developed for HuaiMei Medical
- Based on original website: https://huaimeiting.42web.io
- Icons: Emoji icons (native browser support)

## License

GNU General Public License v2 or later
http://www.gnu.org/licenses/gpl-2.0.html

## Changelog

### Version 1.0.0 (2026-04-28)
- Initial release
- Complete theme with all features
- Responsive design
- Bilingual content support
