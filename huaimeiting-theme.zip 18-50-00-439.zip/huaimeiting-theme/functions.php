<?php

if (!defined('ABSPATH')) {
    exit;
}

function huaimeiting_theme_setup() {
    add_theme_support('title-tag');
    add_theme_support('post-thumbnails');
    add_theme_support('custom-logo', array(
        'height'      => 100,
        'width'       => 400,
        'flex-height' => true,
        'flex-width'  => true,
    ));
    add_theme_support('html5', array(
        'search-form',
        'comment-form',
        'comment-list',
        'gallery',
        'caption',
    ));
    
    load_theme_textdomain('huaimeiting-theme', get_template_directory() . '/languages');
}
add_action('after_setup_theme', 'huaimeiting_theme_setup');

function huaimeiting_theme_scripts() {
    wp_enqueue_style('huaimeiting-common', get_template_directory_uri() . '/assets/common-bundle.css', array(), '1.0.0');
    wp_enqueue_style('huaimeiting-bundle', get_template_directory_uri() . '/assets/a188dd95aa090019411fc98837eab82f-bundle.css', array(), '1.0.0');
    
    wp_enqueue_script('huaimeiting-common-js', get_template_directory_uri() . '/assets/common-bundle.js', array('jquery'), '1.0.0', true);
    wp_enqueue_script('huaimeiting-bundle-js', get_template_directory_uri() . '/assets/a188dd95aa090019411fc98837eab82f-bundle.js', array('jquery'), '1.0.0', true);
}
add_action('wp_enqueue_scripts', 'huaimeiting_theme_scripts');
