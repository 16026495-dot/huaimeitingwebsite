<?php
/**
 * The front page template file - 100% Exact Replica
 *
 * @package HuaiMei_Medical_Theme
 */

get_header();
?>

<!DOCTYPE html>
<html lang="zh-CN" class="translated-ltr" style="scroll-behavior: smooth;">
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
    
    <link href="<?php echo get_template_directory_uri(); ?>/assets/a188dd95aa090019411fc98837eab82f-bundle.css" rel="stylesheet" type="text/css">
    <link href="<?php echo get_template_directory_uri(); ?>/assets/common-bundle.css" rel="stylesheet" type="text/css">
    <link href="<?php echo get_template_directory_uri(); ?>/assets/css" rel="stylesheet" type="text/css">
    <link href="<?php echo get_template_directory_uri(); ?>/assets/css(1)" rel="stylesheet" type="text/css">
</head>

<body class="site site-lang-en">
    <div id="wb_root" class="root wb-layout-vertical">
        <div class="wb_sbg"></div>
        
        <!-- Header Section -->
        <div id="wb_header_a188dd95aa090019411fc98837eab82f" class="wb_element wb-layout-element" data-plugin="LayoutElement">
            <div class="wb_content wb-layout-vertical">
                <!-- Logo and Title -->
                <div id="a188dd958a1d744b1ecef878c7823d18" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                    <div class="wb_content wb-layout-horizontal">
                        <div id="a188dd958a1d75e7448036b70ce81d77" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                            <div class="wb_content wb-layout-horizontal">
                                <div id="a188dd958a1d76fbb08c824e1b595174" class="wb_element wb_element_picture" data-plugin="Picture" title="">
                                    <div class="wb_picture_wrap" style="height: 100%">
                                        <div class="wb-picture-wrapper" style="overflow: visible; display: flex">
                                            <a href="<?php echo esc_url(home_url('/')); ?>">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="13.5%" viewBox="0 0 2049.02083 1793.982" style="direction: ltr; color:#000000">
                                                    <text x="1.02083" y="1537.02" font-size="1792" fill="currentColor" style="font-family: &quot;FontAwesome&quot;"></text>
                                                </svg>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                                <div id="a188dd958a1e00028cd2ea38dfb4ab5c" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                    <h5 class="wb-stl-subtitle" style="text-align: center;">医用塑身衣全生命周期解决方案</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content Section -->
        <div id="a188dd958a1d06d27447bf923eaed95f" class="wb_element wb-layout-element" data-plugin="LayoutElement">
            <div class="wb_content wb-layout-vertical">
                
                <!-- Our Strengths Section -->
                <div id="a188dd958a1d077663bced7298f49496" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                    <h1 class="wb-stl-heading1">我们的优势核心优势</h1>
                </div>
                
                <div id="a188dd958a1d0801a566b98644adb140" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                    <div class="wb_content wb-layout-horizontal">
                        
                        <!-- Strength 01 -->
                        <div id="a188dd958a1d09e1186119eff9787fda" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                            <div class="wb_content wb-layout-vertical">
                                <div id="a188dd958a1d0a7f010c9eb16dd7972c" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                                    <div class="wb_content wb-layout-vertical">
                                        <div id="a188dd958a1d0b717a35c680bb00a360" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                            <h1 class="wb-stl-heading1">01</h1>
                                        </div>
                                    </div>
                                </div>
                                <div id="a188dd958a1d0c0e741d4192549f7033" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                    <h2 class="wb-stl-heading2">品牌使命</h2>
                                </div>
                                <div id="a188dd958a1d0d08a821070fd8f31254" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                    <p class="wb-stl-normal">我们秉持"专注医疗"的理念，专注医用塑身衣研发与生产，致力于为犹太人、产后人群提供安全有效的康复解决方案。</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Strength 02 -->
                        <div id="a188dd958a1d0ebb82e6923185e30c31" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                            <div class="wb_content wb-layout-vertical">
                                <div id="a188dd958a1d0f4b83fe246a34b17cd0" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                                    <div class="wb_content wb-layout-vertical">
                                        <div id="a188dd958a1d10044b3b46df08b4e695" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                            <h1 class="wb-stl-heading1">02</h1>
                                        </div>
                                    </div>
                                </div>
                                <div id="a188dd958a1d11068ddeb747a735b83c" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                    <h2 class="wb-stl-heading2">研发力量</h2>
                                </div>
                                <div id="a188dd958a1d12f0152c365272a37fef" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                    <p class="wb-stl-normal">联合三甲医院临床医师共同研发，依据人体工学与临床数据，确保压力值精准达标，符合医用级标准。</p>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Strength 03 -->
                        <div id="a188dd958a1d13e078834a91e7b05190" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                            <div class="wb_content wb-layout-vertical">
                                <div id="a188dd958a1d14436443e925b662dd73" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                                    <div class="wb_content wb-layout-vertical">
                                        <div id="a188dd958a1d152beae7999a57507a33" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                            <h1 class="wb-stl-heading1">03</h1>
                                        </div>
                                    </div>
                                </div>
                                <div id="a188dd958a1d161e6259d41da0c13eeb" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                    <h2 class="wb-stl-heading2">服务网络</h2>
                                </div>
                                <div id="a188dd958a1d17e21fe95db5b5e53ce1" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                    <p class="wb-stl-normal">提供从产品定制到临床指导的一站式服务，覆盖全国的销售与售后网络，支持医疗机构与终端用户。</p>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
                
                <!-- Products & Services Section -->
                <div id="a188dd958a1d18d8a1770632cbc75017" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                    <div class="wb_content wb-layout-vertical">
                        <div id="a188dd958a1d199da1a40eb97f6af509" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                            <h1 class="wb-stl-heading1" style="text-align: center;"><span style="color:rgba(255,255,255,1);">我们的产品与服务 / 产品与服务</span></h1>
                        </div>
                        <div id="a188dd958a1d1ae9521131dd107ba8e8" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                            <p class="wb-stl-normal" style="text-align: center;"><span style="color:rgba(194,194,194,1);">专业医用压力衣，适用于术后恢复和产后护理。</span></p>
                        </div>
                        
                        <!-- Services Grid -->
                        <div id="a188dd958a1d1b486f18f9e5055ce6a8" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                            <div class="wb_content wb-layout-horizontal">
                                
                                <!-- Service 1: Postoperative Recovery -->
                                <div id="a188dd958a1d1cda79bee87af9bd9f88" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                                    <div class="wb_content wb-layout-horizontal">
                                        <div id="a188dd958a1d1df091159c2c04536387" class="wb_element wb_element_picture" data-plugin="Picture" title="">
                                            <div class="wb_picture_wrap" style="height: 100%">
                                                <div class="wb-picture-wrapper" style="overflow: visible; display: flex">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="28" viewBox="0 0 1793.982 1793.982" style="direction: ltr; color:#ffffff">
                                                        <text x="1.501415" y="1537.02" font-size="1792" fill="currentColor" style="font-family: &quot;FontAwesome&quot;"></text>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="a188dd958a1d1e3434334338ab66a7e4" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                            <h3 class="wb-stl-heading3"><span style="color:rgba(255,255,255,1);">术后恢复系列<br>童话修复系列（吸脂/隆胸/胸外科专用塑身衣）</span></h3>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Service 2: Postnatal Care -->
                                <div id="a188dd958a1d1fe85d90869084f93afe" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                                    <div class="wb_content wb-layout-horizontal">
                                        <div id="a188dd958a1d20d341e1cbbf66cfade0" class="wb_element wb_element_picture" data-plugin="Picture" title="">
                                            <div class="wb_picture_wrap" style="height: 100%">
                                                <div class="wb-picture-wrapper" style="overflow: visible; display: flex">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="28" viewBox="0 0 1793.982 1793.982" style="direction: ltr; color:#ffffff">
                                                        <text x="1.501415" y="1537.02" font-size="1792" fill="currentColor" style="font-family: &quot;FontAwesome&quot;"></text>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="a188dd958a1d21c2eca405aa40d83b88" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                            <h3 class="wb-stl-heading3"><span style="color:rgba(255,255,255,1);">产后护理系列<br>产后康复系列（收腹/束身/京都专用塑身衣）</span></h3>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Service 3: Customized Solutions -->
                                <div id="a188dd958a1d22c1a4a984b04325a92f" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                                    <div class="wb_content wb-layout-horizontal">
                                        <div id="a188dd958a1d23ed18cbc524a1963106" class="wb_element wb_element_picture" data-plugin="Picture" title="">
                                            <div class="wb_picture_wrap" style="height: 100%">
                                                <div class="wb-picture-wrapper" style="overflow: visible; display: flex">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="28" viewBox="0 0 1793.982 1793.982" style="direction: ltr; color:#ffffff">
                                                        <text x="65.501415" y="1537.02" font-size="1792" fill="currentColor" style="font-family: &quot;FontAwesome&quot;"></text>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="a188dd958a1d248e5284c41dfda063e0" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                            <h3 class="wb-stl-heading3"><span style="color:rgba(255,255,255,1);">定制化医疗解决方案<br>医疗机构定制方案</span></h3>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Service 4: 24/7 Guidance -->
                                <div id="a188dd958a1d25cec2a2858489b0982b" class="wb_element wb-layout-element" data-plugin="LayoutElement">
                                    <div class="wb_content wb-layout-horizontal">
                                        <div id="a188dd958a1d26fd84528732f803ff3d" class="wb_element wb_element_picture" data-plugin="Picture" title="">
                                            <div class="wb_picture_wrap" style="height: 100%">
                                                <div class="wb-picture-wrapper" style="overflow: visible; display: flex">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="28" viewBox="0 0 1793.982 1793.982" style="direction: ltr; color:#ffffff">
                                                        <text x="129.501415" y="1537.02" font-size="1792" fill="currentColor" style="font-family: &quot;FontAwesome&quot;"></text>
                                                    </svg>
                                                </div>
                                            </div>
                                        </div>
                                        <div id="a188dd958a1d27586c0ac4f0dfdbf853" class="wb_element wb_text_element" data-plugin="TextArea" style=" line-height: normal;">
                                            <h3 class="wb-stl-heading3"><span style="color:rgba(255,255,255,1);">24/7临床指导<br>7×24小时专业穿戴指导</span></h3>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                        
                    </div>
                </div>
                
            </div>
        </div>
        
    </div>

    <script src="<?php echo get_template_directory_uri(); ?>/assets/common-bundle.js" type="text/javascript"></script>
    <script src="<?php echo get_template_directory_uri(); ?>/assets/a188dd95aa090019411fc98837eab82f-bundle.js" type="text/javascript"></script>
    
    <?php wp_footer(); ?>
</body>
</html>
